const display = document.querySelector(".display");
const promien = document.querySelector("#Promien")
const submit = document.querySelector("#submit")

function handleSubmit(event) {
            event.preventDefault();
}


submit.addEventListener("click", function(){
     
    const PoleKola = promien.value * promien.value * Math.PI;

    const WynikPola = document.createElement('p');

    WynikPola.style.color = "#A0F";
    
    const WynikPolaNode = document.createTextNode(`Pole koła wynosi: ${PoleKola} cm^2`);
    WynikPola.append(WynikPolaNode);

    display.append(WynikPola);
    
    const usuwak = document.createElement('button');
    usuwak.style.backgroundColor = "FFF";
    usuwak.color = "000";
    
    usuwak.addEventListener("click", function(){
        this.remove
    })

    display.append(usuwak);
    display.append(WynikPola);
});

